Make this your uploads folder for addbooks1.php

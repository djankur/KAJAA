<?php
 $con = mysqli_connect("localhost","root","","kajaa");
?>